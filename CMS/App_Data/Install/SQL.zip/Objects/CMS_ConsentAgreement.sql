SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_ConsentAgreement](
	[ConsentAgreementID] [int] IDENTITY(1,1) NOT NULL,
	[ConsentAgreementGuid] [uniqueidentifier] NOT NULL,
	[ConsentAgreementRevoked] [bit] NOT NULL,
	[ConsentAgreementContactID] [int] NOT NULL,
	[ConsentAgreementConsentID] [int] NOT NULL,
	[ConsentAgreementConsentHash] [nvarchar](100) NULL,
	[ConsentAgreementTime] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_ConsentAgreement] PRIMARY KEY CLUSTERED 
(
	[ConsentAgreementID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_CMS_ConsentAgreement_ConsentAgreementContactID_ConsentAgreementConsentID] ON [dbo].[CMS_ConsentAgreement]
(
	[ConsentAgreementContactID] ASC,
	[ConsentAgreementConsentID] ASC
)
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement] ADD  CONSTRAINT [DEFAULT_CMS_ConsentAgreement_ConsentAgreementGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [ConsentAgreementGuid]
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement] ADD  CONSTRAINT [DEFAULT_CMS_ConsentAgreement_ConsentAgreementRevoked]  DEFAULT ((0)) FOR [ConsentAgreementRevoked]
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement] ADD  CONSTRAINT [DEFAULT_CMS_ConsentAgreement_ConsentAgreementContactID]  DEFAULT ((0)) FOR [ConsentAgreementContactID]
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement] ADD  CONSTRAINT [DEFAULT_CMS_ConsentAgreement_ConsentAgreementConsentID]  DEFAULT ((0)) FOR [ConsentAgreementConsentID]
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement] ADD  CONSTRAINT [DEFAULT_CMS_ConsentAgreement_ConsentAgreementTime]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [ConsentAgreementTime]
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ConsentAgreement_ConsentAgreementConsentID_CMS_Consent] FOREIGN KEY([ConsentAgreementConsentID])
REFERENCES [dbo].[CMS_Consent] ([ConsentID])
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement] CHECK CONSTRAINT [FK_CMS_ConsentAgreement_ConsentAgreementConsentID_CMS_Consent]
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement]  WITH CHECK ADD  CONSTRAINT [FK_CMS_ConsentAgreement_ConsentAgreementContactID_OM_Contact] FOREIGN KEY([ConsentAgreementContactID])
REFERENCES [dbo].[OM_Contact] ([ContactID])
GO
ALTER TABLE [dbo].[CMS_ConsentAgreement] CHECK CONSTRAINT [FK_CMS_ConsentAgreement_ConsentAgreementContactID_OM_Contact]
GO
